#!/bin/bash

cd /data/hhxxj
sh audit-restart.sh