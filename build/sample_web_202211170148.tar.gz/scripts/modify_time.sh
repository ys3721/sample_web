#!/usr/bin/env bash

sudo date -s "$1"