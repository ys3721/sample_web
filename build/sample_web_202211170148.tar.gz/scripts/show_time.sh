#!/usr/bin/env bash

date